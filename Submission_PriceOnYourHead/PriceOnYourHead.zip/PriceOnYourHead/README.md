# Price on Your Head

A 3D cyberpunk stealth heist and score attack game built in Unreal Engine 5.8 with pure C++.

## Premise
You are an auction porter on a floating sale barge in the flooded financial district, and tonight's Lot One is a bankrupt billionaire's frozen head. You mean to steal it. First, spend three insider tips on the deck plan to reveal camera drones or bonus lots, then pick two tools: a fake lot tag, a smoke cartridge, a magnetic hook or a decoy bid paddle. In third person, cyan holograms and red bid-light wash the rain-black deck, frosted canisters and masked bidders. WASD moves, the mouse aims, Ctrl crouches, E grabs and Q uses a tool. Crouch between velvet plinths, using your information and tools to pass drones. Each lot you carry projects its price above your head, and drones read price tags from across the hall, so a richer haul is spotted sooner. Bidding wars flash red and blind drones briefly; your paddle can start one, opening a loud path forward. Bonus lots multiply your score, but carrying them raises your visible price and their detours delay the faster exits that rank higher. Decide when your haul is enough, grab Lot One and run through smoke or bidding chaos to the skiff. Escape by skiff with Lot One and a haul above the target score for a medal. Lose if drones pin you or the final gavel sells Lot One first.

## Original Idea Text (Contract)
- **ID:** 1986959601 / `idea-7F8AB478AD20`
- **Title:** Price on Your Head
- **Genre:** Stealth Heist · Score Attack
- **Gameplay Family:** Stealth & Infiltration
- **Core Mechanic:** Plan, then run a heist
- **Perspective:** Third-person 3D
- **Setting:** Cyberpunk & Dystopia
- **Run Length:** About 90 seconds, plus planning
- **Controls:** Mouse spends tips and picks tools; WASD move, mouse aims, Ctrl crouches, E grabs, Q uses a tool.
- **Objective:** Escape with the billionaire's frozen head (Lot One) and enough lots to beat the target score.
- **Win Condition:** Escape by skiff carrying Lot One and a haul above the target score for a medal, with faster exits ranking higher.
- **Lose Condition:** You lose if drones pin you or the final gavel sells Lot One first.

## Differentiation
This is Game #1 on this workstation. It sets the baseline for third-person stealth navigation, dynamic drone detection cones, inventory carrying price projection, holographic UI shaders, and deterministic autoplay testing.

## Rules & Verification Table

| Rule / Condition | Expected Result | Verification / Autoplay Test |
|---|---|---|
| Planning Phase | Player spends up to 3 tips to reveal drones/lots and selects 2 tools. | `Test_PlanningSelection`: Verify tips decrease and 2 tool slots are filled before heist start. |
| Movement & Crouch | WASD moves at 450 cm/s; Ctrl crouches (200 cm/s, reduces detection radius by 50%). | `Test_CrouchSpeedAndStealth`: Check player max walk speed and detection multiplier when crouching. |
| Lot Carrying Price | Carrying Lot One adds 500k to bounty; bonus lots add 100k-250k each. Price displays above head in cyan/red. | `Test_BountyProjection`: Verify visible price string matches total inventory value. |
| Drone Detection | Drones have conical search vision. Detection range scales with current visible price. | `Test_DroneDetectionScaling`: Place drone at distance D; verify detection triggers with high bounty and fails with low bounty. |
| Bidding War Blind | Starting or triggering a bidding war pulses red light and blinds drones for 4.0 seconds. | `Test_BiddingWarDroneBlind`: Trigger bidding war; assert drone perception is disabled for 4s. |
| Tool: Smoke Cartridge | Drops smoke volume breaking line of sight for 6.0 seconds. | `Test_SmokeToolLOS`: Test raycast obstruction between drone and player inside smoke volume. |
| Tool: Fake Lot Tag | Temporarily zeroes projected bounty for 8.0 seconds. | `Test_FakeTagTool`: Verify visible price returns 0 during active duration. |
| Tool: Decoy Paddle | Initiates an instant bidding war at the targeted plinth. | `Test_DecoyPaddle`: Confirm plinth enters bidding war state on use. |
| Win Condition | Exit via escape skiff with Lot One and score >= target score. | `Test_WinByEscape`: Reach skiff with Lot One; verify victory screen and medal award. |
| Lose Condition 1: Pinned | If drone reaches player and stays within 150 cm for 2.0s without evasion. | `Test_LosePinnedByDrone`: Keep player immobile near drone; verify game over state. |
| Lose Condition 2: Gavel Sold | Gavel timer expires (90 seconds of heist play) before Lot One is secured. | `Test_LoseGavelTimeout`: Advance world timer past 90s; verify Lot One sold loss condition. |
| Autoplay Flag | Launching with `-autoplay` plays through planning, stealth route, Lot One pickup, and skiff escape. | `Test_FullAutoplayRun`: Automated bot inputs achieve clean victory with 0 QA violations. |
